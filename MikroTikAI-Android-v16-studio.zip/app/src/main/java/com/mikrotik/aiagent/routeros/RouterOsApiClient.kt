package com.mikrotik.aiagent.routeros
import java.net.InetSocketAddress
import java.net.Socket
import java.io.*
import java.security.MessageDigest
import javax.net.ssl.SSLSocketFactory

data class Reply(val type:String,val attrs:Map<String,String>)

class RouterOsApiClient(
    private val host:String, private val user:String, private val pass:String,
    private val tls:Boolean=false
){
    private var socket:Socket?=null
    private var input:BufferedInputStream?=null
    private var output:BufferedOutputStream?=null

    fun connect(){
        if(socket?.isConnected==true && socket?.isClosed==false)return
        val port=if(tls)8729 else 8728
        socket=if(tls){
            val raw=Socket(); raw.connect(InetSocketAddress(host,port),7000)
            (SSLSocketFactory.getDefault().createSocket(raw,host,port,true)).also{it.startHandshake()}
        } else Socket().also{it.connect(InetSocketAddress(host,port),7000)}
        input=BufferedInputStream(socket!!.getInputStream()); output=BufferedOutputStream(socket!!.getOutputStream())
        val first=rawCommand(listOf("/login","=name=$user","=password=$pass"))
        val challenge=first.firstOrNull()?.attrs?.get("=ret")
        if(challenge!=null){
            val digest=MessageDigest.getInstance("MD5").digest(
                byteArrayOf(0)+pass.toByteArray(Charsets.UTF_8)+challenge.chunked(2).map{it.toInt(16).toByte()}.toByteArray()
            ).joinToString(""){"%02x".format(it)}
            rawCommand(listOf("/login","=name=$user","=response=00$digest"))
        }
    }
    fun command(words:List<String>):List<Reply>{connect();return rawCommand(words)}
    private fun rawCommand(words:List<String>):List<Reply>{
        RouterOsWordCodec.writeSentence(output!!,words)
        val result=mutableListOf<Reply>()
        while(true){
            val ws=mutableListOf<String>()
            while(true){val w=RouterOsWordCodec.readWord(input!!);if(w.isEmpty())break;ws+=w}
            if(ws.isEmpty())continue
            val attrs=linkedMapOf<String,String>()
            ws.drop(1).forEach{w->if(w.startsWith("=")){val x=w.indexOf('=',1);if(x>0)attrs[w.substring(0,x)]=w.substring(x+1)}}
            val r=Reply(ws.first(),attrs);result+=r
            if(r.type=="!trap"||r.type=="!fatal")throw IOException(r.attrs["=message"]?:"RouterOS error")
            if(r.type=="!done")return result
        }
    }
    fun close(){runCatching{socket?.close()};socket=null}
}
