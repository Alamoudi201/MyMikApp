package com.mikrotik.aiagent.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mikrotik.aiagent.agent.AgentController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UiState(
    val host:String="192.168.88.1", val user:String="admin", val password:String="",
    val tls:Boolean=true, val status:String="غير متصل", val identity:String="—",
    val cpu:String="—", val memory:String="—", val uptime:String="—",
    val diagnosis:String="—", val output:String="", val busy:Boolean=false
)

class AgentViewModel:ViewModel(){
    private val controller=AgentController()
    private val _state=MutableStateFlow(UiState())
    val state=_state.asStateFlow()
    fun host(v:String){_state.value=_state.value.copy(host=v)}
    fun user(v:String){_state.value=_state.value.copy(user=v)}
    fun password(v:String){_state.value=_state.value.copy(password=v)}
    fun tls(v:Boolean){_state.value=_state.value.copy(tls=v)}
    fun connect(){
        val s=_state.value; work{controller.connect(s.host,s.user,s.password,s.tls);_state.value=_state.value.copy(status="متصل",identity=controller.identity())}
    }
    fun scan(){
        work{
            val m=controller.snapshot(); val d=controller.diagnose()
            _state.value=_state.value.copy(cpu="${m.cpu}%",memory="${"%.1f".format(m.memory)}%",uptime=m.uptime,diagnosis=d.joinToString("\n"){"${it.severity}: ${it.area} — ${it.message}"})
        }
    }
    fun interfaces(){work{_state.value=_state.value.copy(output=controller.readInterfaces())}}
    private fun work(block:suspend()->Unit){
        viewModelScope.launch(Dispatchers.IO){
            _state.value=_state.value.copy(busy=true)
            runCatching{block()}.onFailure{_state.value=_state.value.copy(status="خطأ: ${it.message}")}
            _state.value=_state.value.copy(busy=false)
        }
    }
    override fun onCleared(){controller.close();super.onCleared()}
}
