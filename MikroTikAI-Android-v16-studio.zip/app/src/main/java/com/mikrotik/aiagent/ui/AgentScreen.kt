package com.mikrotik.aiagent.ui
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun AgentScreen(vm:AgentViewModel){
    val s by vm.state.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("MikroTik AI Agent v16",style=MaterialTheme.typography.headlineSmall)
        Text("الاتصال الحقيقي + الفحص + التشخيص",style=MaterialTheme.typography.bodyMedium)
        OutlinedTextField(s.host,{vm.host(it)},label={Text("Router IP / Host")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(s.user,{vm.user(it)},label={Text("Username")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(s.password,{vm.password(it)},label={Text("Password")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Text("API-SSL");Switch(s.tls,{vm.tls(it)})}
        Button(vm::connect,enabled=!s.busy,modifier=Modifier.fillMaxWidth()){Text("اتصال بالراوتر")}
        Text("الحالة: ${s.status}")
        Text("Identity: ${s.identity}")
        HorizontalDivider()
        Button(vm::scan,enabled=!s.busy,modifier=Modifier.fillMaxWidth()){Text("فحص وتشخيص")}
        Text("CPU: ${s.cpu}   RAM: ${s.memory}")
        Text("Uptime: ${s.uptime}")
        Text("التشخيص:\n${s.diagnosis}")
        OutlinedButton(vm::interfaces,enabled=!s.busy,modifier=Modifier.fillMaxWidth()){Text("عرض الواجهات")}
        if(s.output.isNotBlank()) Text(s.output,style=MaterialTheme.typography.bodySmall)
        Text("الأمان: أوامر القراءة متاحة، أما التغييرات فتحتاج طبقة Planner/Safety وموافقة المستخدم.",style=MaterialTheme.typography.bodySmall)
    }
}
