package com.mikrotik.aiagent.routeros
import java.io.InputStream
import java.io.OutputStream

object RouterOsWordCodec {
    fun writeWord(out:OutputStream, word:String) {
        val b=word.toByteArray(Charsets.UTF_8); writeLength(out,b.size); out.write(b)
    }
    fun writeSentence(out:OutputStream, words:List<String>) {
        words.forEach{writeWord(out,it)}; writeWord(out,""); out.flush()
    }
    fun readWord(input:InputStream):String {
        val n=readLength(input); if(n==0)return ""
        val b=ByteArray(n); var p=0
        while(p<n){val r=input.read(b,p,n-p); if(r<0)error("RouterOS stream ended"); p+=r}
        return b.toString(Charsets.UTF_8)
    }
    private fun writeLength(out:OutputStream,n:Int){
        when {
            n<0x80->out.write(n)
            n<0x4000->{out.write((n shr 8) or 0x80);out.write(n and 255)}
            n<0x200000->{out.write((n shr 16) or 0xC0);out.write(n shr 8 and 255);out.write(n and 255)}
            n<0x10000000->{out.write((n shr 24) or 0xE0);out.write(n shr 16 and 255);out.write(n shr 8 and 255);out.write(n and 255)}
            else->{out.write(0xF0);out.write(n shr 24 and 255);out.write(n shr 16 and 255);out.write(n shr 8 and 255);out.write(n and 255)}
        }
    }
    private fun readLength(i:InputStream):Int{
        val f=i.read(); if(f<0)error("EOF")
        fun b():Int{val x=i.read();if(x<0)error("EOF");return x}
        return when{
            f and 0x80==0->f
            f and 0xC0==0x80->((f and 63) shl 8) or b()
            f and 0xE0==0xC0->((f and 31) shl 16) or (b() shl 8) or b()
            f and 0xF0==0xE0->((f and 15) shl 24) or (b() shl 16) or (b() shl 8) or b()
            f==0xF0->(b() shl 24) or (b() shl 16) or (b() shl 8) or b()
            else->error("Invalid API length")
        }
    }
}
