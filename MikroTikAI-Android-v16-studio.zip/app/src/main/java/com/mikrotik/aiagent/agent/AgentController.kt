package com.mikrotik.aiagent.agent
import com.mikrotik.aiagent.core.*
import com.mikrotik.aiagent.routeros.RouterOsApiClient

class AgentController {
    private var client:RouterOsApiClient?=null
    fun connect(host:String,user:String,pass:String,tls:Boolean):String{
        client=RouterOsApiClient(host,user,pass,tls); client!!.connect()
        return "Connected"
    }
    fun identity():String{
        val r=client!!.command(listOf("/system/identity")).firstOrNull{it.type=="!re"}
        return r?.attrs?.get("=name") ?: "Unknown"
    }
    fun snapshot():MetricSnapshot{
        val r=client!!.command(listOf("/system/resource")).firstOrNull{it.type=="!re"}
        val total=r?.attrs?.get("=total-memory")?.toDoubleOrNull()?:0.0
        val free=r?.attrs?.get("=free-memory")?.toDoubleOrNull()?:total
        return MetricSnapshot(
            r?.attrs?.get("=cpu-load")?.toDoubleOrNull()?:0.0,
            if(total>0)((total-free)/total)*100 else 0.0,
            r?.attrs?.get("=uptime")?:"—",
            client!!.command(listOf("/interface/print")).count{it.type=="!re"}
        )
    }
    fun diagnose():List<Finding>{
        val route=client!!.command(listOf("/ip/route/print","?dst-address=0.0.0.0/0"))
        return if(route.none{it.type=="!re"})
            listOf(Finding("HIGH","Routing","No default route detected"))
        else listOf(Finding("OK","Routing","Default route detected"))
    }
    fun readInterfaces():String=
        client!!.command(listOf("/interface/print")).filter{it.type=="!re"}
            .take(12).joinToString("\n"){it.attrs.toString()}
    fun close(){client?.close()}
}
