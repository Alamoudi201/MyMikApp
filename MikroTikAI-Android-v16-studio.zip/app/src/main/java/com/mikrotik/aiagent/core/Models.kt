package com.mikrotik.aiagent.core
enum class RouterOsVersion { V6, V7, UNKNOWN }
enum class RiskLevel { READ, LOW_RISK_WRITE, HIGH_RISK_WRITE, DESTRUCTIVE }
data class DeviceProfile(val host:String,val identity:String,val version:RouterOsVersion,val tls:Boolean)
data class MetricSnapshot(val cpu:Double,val memory:Double,val uptime:String,val interfaces:Int)
data class Finding(val severity:String,val area:String,val message:String)
data class CommandPlan(val description:String,val risk:RiskLevel,val command:String)
